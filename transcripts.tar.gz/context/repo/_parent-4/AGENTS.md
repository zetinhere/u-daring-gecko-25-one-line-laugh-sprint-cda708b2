# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

- QR sign-in PNGs: render with the `qrcode` module bundled inside the baw install (`/usr/lib/node_modules/@binance/agentic-wallet/node_modules/qrcode`) — it takes ~200ms. `npx -y qrcode` is too slow (2+ min download) and the ~5-min QR expires before the user can scan it (happened 2026-11-13: first QR of the evening expired unscanned).
